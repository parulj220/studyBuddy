function showAlert() {
    alert("Welcome! Let's start coding.");
}
