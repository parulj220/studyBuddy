package com.summarizer.service;

import com.summarizer.entity.TextContent;
import com.summarizer.repository.TextContentRepository;
import com.summarizer.utility.AIClient;
import com.summarizer.utility.GeminiAIClient;
import okhttp3.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.io.IOException;

@Service
public class SummarizationService {

    @Autowired
    private TextContentRepository repository;

    @Autowired
    private GeminiAIClient geminiAIClient;

    public String askMe(String inputText) throws IOException {
        return  geminiAIClient.sendRequest(inputText);
    }

    public String simulateTranslation(String inputText, String lang) throws IOException {

        String requestText = inputText + ". Please translate this text to " + lang + ".";
        return  geminiAIClient.sendRequest(requestText);
    }
    public String summarizeText(String inputText) throws IOException {

        String requestText = inputText + ". Please summarize this text. and keep it short.";
        return  geminiAIClient.sendRequest(requestText);
    }
}
