package com.summarizer.utility;

import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.time.Duration;
import java.util.List;
import java.util.Map;

@Component
public class AIClient {

    //private static final String API_URL = "https://openrouter.ai/api/v1";
    private static final String API_URL = "https://openrouter.ai/api/v1/chat/completions";
    //private static final String API_URL = "https://api.openai.com/v1/completions";

    private static final String API_KEY = "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";

    public String getSummary(String text) {
        return sendRequest(text, "Generate a concise summary of the following text:");
    }

    public String extractKeywords(String text) {
        return sendRequest(text, "Extract the key topics and keywords from the following text:");
    }

    public String analyzeSentiment(String text) {
        return sendRequest(text, "Analyze the sentiment of the following text:");
    }

    private String sendRequest(String input, String prompt) {
        //RestTemplate restTemplate = new RestTemplate();

        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + API_KEY);
        headers.setContentType(MediaType.APPLICATION_JSON);

        //String requestBody = "{\"prompt\": \"" + prompt + " " + input + "\", \"max_tokens\": 100}";
        Map<String, Object> body = Map.of(
                "model", "openai/gpt-4o",
                "messages", List.of(Map.of("role", "user", "content", input + " " + prompt))
        );
        HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(body, headers);
        RestTemplate restTemplate = new RestTemplateBuilder()
                .setConnectTimeout(Duration.ofSeconds(60))
                .setReadTimeout(Duration.ofSeconds(60))
                .build();

        ResponseEntity<String> response = restTemplate.postForEntity(API_URL, requestEntity, String.class);

        return response.getBody();
    }
}
