package com.summarizer.utility;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.summarizer.dto.Response;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class GeminiAIClient {

    private static final String API_KEY = "AIzaSyDcYtbMLfBcw6BIbLBb3zvWJdPzx818xHo";
    private static final String BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent";

    public String sendRequest(String input) throws IOException {
        // Create RestTemplate instance
        RestTemplate restTemplate = new RestTemplate();

        // Define the endpoint URL
        String url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=AIzaSyDcYtbMLfBcw6BIbLBb3zvWJdPzx818xHo";

        // Create the request body
        // Create the nested structure for the request body
        Map<String, Object> part = new HashMap<>();
        part.put("text", input);

        Map<String, Object> content = new HashMap<>();
        content.put("parts", List.of(part));

        Map<String, Object> requestBodyMap = new HashMap<>();
        requestBodyMap.put("contents", List.of(content));
        ObjectMapper objectMapper = new ObjectMapper();
        ResponseEntity<String> responseFromGemini = sendRequestBody(requestBodyMap);

        Response response = objectMapper.readValue(responseFromGemini.getBody().getBytes(), Response.class);
        System.out.println("@@@@response is : " + response.toString());
        return response.getCandidates().get(0).getContent().getParts().get(0).getText();
    }


    public ResponseEntity<String> sendRequestBody(Map<String, Object> requestBodyMap) throws JsonProcessingException {
        // Convert the structure to JSON string
        // Define the endpoint URL
        String url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=AIzaSyDcYtbMLfBcw6BIbLBb3zvWJdPzx818xHo";

        ObjectMapper objectMapper = new ObjectMapper();
        String requestBody = objectMapper.writeValueAsString(requestBodyMap);

        // Set the headers
        HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", "application/json");

        // Combine headers and body into an HttpEntity
        HttpEntity<String> entity = new HttpEntity<>(requestBody, headers);
        RestTemplate restTemplate = new RestTemplate();
        // Send the request and capture the response
        return restTemplate.exchange(
                url,
                HttpMethod.POST,
                entity,
                String.class
        );
    }
}
